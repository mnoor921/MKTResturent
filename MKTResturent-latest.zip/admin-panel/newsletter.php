<?php  include "requires/header.php"  ?>

<div class="main-container">
		<div class="xs-pd-20-10 pd-ltr-20">

			<div class="title pb-20">
				<h2 class="h3 mb-0">All Newsletter Subscriber</h2>
			</div>
            <table class="data-table table nowrap">
					<thead>
						<tr>
                            <th>#</th>
							
							<th>Email</th>
							
							<th class="datatable-nosort">Actions</th>
						</tr>
					</thead>
					<tbody>

					<tr>
                        <td>1</td>
                        <td>info@gmail.com</td>

                        <td>
								<div class="table-actions">
									<a href='#' data-color="#265ed7"><i class="icon-copy dw dw-edit2"></i></a>
									<a href="#" data-color="#e95959"><i class="icon-copy dw dw-delete-3"></i></a>
								</div>
							</td>        

                    </tr>
						
					</tbody>
				</table>




<?php  include "requires/footer.php"  ?>