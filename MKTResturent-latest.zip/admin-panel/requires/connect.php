<?php 


$connect = mysqli_connect("localhost", "root", "", "mkt");

$connect->connect_error ? die() : null ;


?>