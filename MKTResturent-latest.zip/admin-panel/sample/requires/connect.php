<?php 


$connect = new mysqli("localhost", "root", "", "mkt");
$connect->connect_error ? die() : null ;


?>