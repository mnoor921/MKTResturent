<!-- headers include -->
<?php  include "requires/header.php"  ?>



	<div class="main-container">
		<div class="xs-pd-20-10 pd-ltr-20">

			<div class="title pb-20">
				<h2 class="h3 mb-0">Terms & Conidtion</h2>
			</div>


            <div id="summernote"></div>

                
			
			

			

			
			
		</div>
	</div>

	<?php  include "requires/footer.php"  ?>

	