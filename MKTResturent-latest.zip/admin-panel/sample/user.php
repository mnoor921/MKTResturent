<!-- headers include -->
<?php  include "requires/header.php"  ?>



	<div class="main-container">
		<div class="xs-pd-20-10 pd-ltr-20">

			<div class="title pb-20">
				<h2 class="h3 mb-0">All Users</h2>
			</div>


                    <!-- Data Tables -->
            <div class="card-box pb-10">
				<div class="h5 pd-20 mb-0">Users</div>
				<table class="data-table table nowrap">
					<thead>
						<tr>
                            <th>#</th>
							<th class="table-plus">Name</th>
							<th>Image</th>
							<th>Email</th>
							<th>Password</th>
							<th>Phone</th>
							<th>Address</th>
							<th class="datatable-nosort">Status</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>
								1
							</td>
							<td>Female</td>
							<td>info@gmail.com</td>
							<td>info@gmail.com</td>
							<td>info@gmail.com</td>
							<td>*********</td>
							<td>*********</td>
							<td>
								<div class="table-actions">
									<a href="#" data-color="#265ed7"><i class="icon-copy dw dw-edit2"></i></a>
									<a href="#" data-color="#e95959"><i class="icon-copy dw dw-delete-3"></i></a>
								</div>
							</td>
						</tr>
						
					</tbody>
				</table>
			</div>

                
			
			

			

			
			
		</div>
	</div>

	<?php  include "requires/footer.php"  ?>

	