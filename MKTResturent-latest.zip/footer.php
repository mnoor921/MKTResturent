

<footer>
  <div class="container-fluid text-white">
    <div class="row px-5">
      <div class="col-md-3 col-12">
        <div class="footer-text">
          <img src="img/imgpsh_fullsize_anim.png" width="100px" alt="">
          <p class="py-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Alias soluta modi explicabo porro dolore. Inventore rerum alias, numquam, repellendus deleniti aliquam natus repellat, incidunt quidem sed porro laudantium nobis. Similique.</p>
          <hr>
          <a href=""><i class="fa fa-facebook"></i></a>
          <a href=""><i class="fa fa-twitter"></i></a>
          <a href=""><i class="fa fa-skype"></i></a>
          <a href=""><i class="fa fa-instagram"></i></a>
        </div>
      </div>
      <div class="col-md-3">
        <div class="usefull-links p-4">
          <h2 class="mb-5">Imp. Links</h2>
          <ul>
            <li><a href="about.php ">About Us</a></li>
            <li><a href="tern.php">Terms & Condition</a></li>
            <li><a href="privacy.php">Privacy Policy</a></li>
            <li><a href="blog.php">Blog</a></li>
          </ul>
        </div>
        
      </div>
      <div class="col-md-3">
        <div class="usefull-links p-4">
          <h2 class="mb-5">Usefull Links</h2>
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            <li><a href="login.php">Login / Sign up</a></li>
            <!-- <li><a href="">Blog</a></li> -->
            <li><a href="profile.php">Profile</a></li>
          </ul>
        </div>
        
      </div>
      
      <div class="col-md-3 col-12">
        <div class="opening p-4">
          <h4 class="mb-5">Opening Hours</h4>
          <div class="hour d-flex">
            <p>Sunday</p>
            <p>24-Hour Shift</p>
          </div>
          <hr>
          <div class="hour d-flex">
            <p>Monday</p>
            <p>24-Hour Shift</p>
          </div>
          <hr>
          <div class="hour d-flex">
            <p>Tuesday</p>
            <p>24-Hour Shift</p>
          </div>
          <hr>
          <div class="hour d-flex">
            <p>Friday</p>
            <p>4PM to 12AM</p>
          </div>
          <hr>
        </div>
      </div>
    </div>
    <hr>
    <p class="text-center">All rights 2021 Reserved By | MKT-Resturant . Developed By: MKT</p>
  </div>
</footer>










<!--   <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


  <!-- Animation on scroll -->
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script src="js/main.js"></script>
</body>
</html>