<?php  include"header.php"  ?>




<!-- Hwero section Section -->
<div class="hero">
    <h2>Product Detail </h2>
</div>

<!-- product Details -->
<div class="container product-detail my-5">
    <div class="row">
        <div class="col-md-6 col-12">
            <div class="product-details-img">
                <img src="img/blog3.jpg" width="100%"  alt="">
            </div>
        </div>
        <div class="col-md-6 col-12">
            <div class="product-detail-text p-2">
                <h1>Product Details</h1>
                <h2>Suchi</h2>
                <h3>Price : Rs 200</h3>
                <span><i class="fa fa-cheese"></i><i class="fa fa-hamburger"></i><i class="fa fa-pizza-slice"></i></span>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Animi labore non adipisci cupiditate nesciunt soluta voluptatum dignissimos amet? Excepturi minus vel ipsam natus exercitationem adipisci assumenda expedita consequatur aliquam incidunt.</p>
                <div class="add-to-cart">
                    <p><i class="fa fa-minus mr-3"></i> 1 <i class="fa fa-plus ml-3"></i> </p>
                    <a href="" class="btn btn-1">Add To Cart <i class="fa fa-shopping-cart ml-2"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>




<?php  include"footer.php"  ?>