<?php  include"header.php"  ?>


<!-- Hwero section Section -->
<div class="hero">
    <h2>Thank You!</h2>
</div>

<!-- thanks you page -->
<div class="container my-5">
    <h2 class="text-center">THANK YOU!</h2>
    <h4 class="text-center"> WE'LL CONTACT YOU WHEN YOUR REQUESTED WILL'BE APPROVED!</h4>
    <div class="thank-table-style p-4">
        <table class="table">
            <thead style="border-radius:10px">
              <tr class="w-100" style="color:#fff;background:  #A30606; border-radius: 10px;">
                <th scope="col" class="w-25" style="border-radius: 10px 0px 0px 10px;">#</th>
                <th scope="col" class="w-75" style="border-radius: 0px 10px 10px 0px;">Content</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td >1</td>
                <td>Mark</td>
              </tr>
              <tr>
                <td >1</td>
                <td>Mark</td>
              </tr>
              <tr>
                <td >1</td>
                <td>Mark</td>
              </tr>
              <tr>
                <td >1</td>
                <td>Mark</td>
              </tr>
             
            </tbody>
          </table>
    </div>
</div>





<?php  include"footer.php"  ?>